"""Create a BankAccount class. Your class should support these methods: deposit,
withdraw, get_balance, change_pin. Create one SavingsAccount class that behaves just like
a BankAccount class, but also has an interest rate and a method that increases the balance by
the appropriate amount of interest. Create another FeeSavingsAccount class that behaves
just like a SavingsAccount, but also charges a fee every time you withdraw money. The fee
should be set in the constructor and deducted before each withdrawal.
"""

class BankAccount:
    def __init__(self, account_number, balance, pin):
        self.account_number = account_number
        self.balance = balance
        self.pin = pin

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if amount > self.balance:
            raise ValueError("Insufficient funds")
        self.balance -= amount

    def get_balance(self):
        return self.balance

    def change_pin(self, new_pin):
        self.pin = new_pin


class SavingsAccount(BankAccount):
    def __init__(self, account_number, balance, pin, interest_rate):
        super().__init__(account_number, balance, pin)
        self.interest_rate = interest_rate

    def increase_balance(self):
        self.balance += self.balance * self.interest_rate


class FeeSavingsAccount(SavingsAccount):
    def __init__(self, account_number, balance, pin, interest_rate, fee):
        super().__init__(account_number, balance, pin, interest_rate)
        self.fee = fee

    def withdraw(self, amount):
        if amount > self.balance:
            raise ValueError("Insufficient funds")
        self.balance -= amount - self.fee


if __name__ == "__main__":
    # Create a BankAccount
    account_number = 123456789
    balance = 1000
    pin = 1234
    bank_account = BankAccount(account_number, balance, pin)

    # Deposit money
    bank_account.deposit(500)

    # Get the balance
    print(bank_account.get_balance())

    # Withdraw money
    bank_account.withdraw(200)

    # Change the PIN
    bank_account.change_pin(4321)

    # Create a SavingsAccount
    account_number = 987654321
    balance = 2000
    pin = 5432
    interest_rate = 0.05
    savings_account = SavingsAccount(account_number, balance, pin, interest_rate)

    # Increase the balance
    savings_account.increase_balance()

    # Get the balance
    print(savings_account.get_balance())

    # Create a FeeSavingsAccount
    account_number = 654321098
    balance = 3000
    pin = 7654
    interest_rate = 0.05
    fee = 10
    fee_savings_account = FeeSavingsAccount(account_number, balance, pin, interest_rate, fee)

    # Withdraw money
    fee_savings_account.withdraw(500)

    # Get the balance
    print(fee_savings_account.get_balance())
