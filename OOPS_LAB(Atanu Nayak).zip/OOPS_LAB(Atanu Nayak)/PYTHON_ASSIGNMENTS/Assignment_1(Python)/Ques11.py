# Search for palindrome and unique words in a text using class method and string
# method

import re

class Palindrome:
    def __init__(self, text):
        self.text = text

    def is_palindrome(self):
        return self.text == self.text[::-1]

class UniqueWords:
    def __init__(self, text):
        self.text = text
        self.words = set(self.text.split())

    def get_unique_words(self):
        return self.words


text = "madam arora madam"

palindrome = Palindrome(text)
print("Is '{}' a palindrome? {}".format(text, palindrome.is_palindrome()))

unique_words = UniqueWords(text)
print("The unique words in '{}' are {}".format(text, unique_words.get_unique_words()))
