# Write a code which yields all terms of the geometric progression a, aq, aq 2 , aq3 , ....
# When the progression produces a term that is greater than 100,000, the generator stops (with
 #a return statement). Compute total time and time within the loop.

import time

def geometric_progression(a, q):
    start_time = time.time()
    current_term = a
    while current_term < 100000:
        yield current_term
        current_term *= q
    end_time = time.time()
    total_time = end_time - start_time
    time_within_loop = end_time - start_time
    return total_time, time_within_loop

a = 2
q = 3
for term in geometric_progression(a, q):
    print(term)
