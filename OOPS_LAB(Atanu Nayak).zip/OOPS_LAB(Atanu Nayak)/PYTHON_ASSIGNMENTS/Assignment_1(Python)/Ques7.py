#Write a function findfiles that recursively descends the directory tree for the specified
#directory and generates paths of all the files in the tree.


import os

def findfiles(directory):
    file_paths = []  # List to store file paths

    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            file_paths.append(file_path)

    return file_paths

#directory stores the path 
directory = '/home/samit/Desktop/Python'
files = findfiles(directory)

# Print the file paths
for file in files:
    print(file)
