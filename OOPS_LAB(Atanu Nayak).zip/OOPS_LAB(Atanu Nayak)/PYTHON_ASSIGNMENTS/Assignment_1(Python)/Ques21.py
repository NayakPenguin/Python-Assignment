"""Write a python program to identify and extract numerical chunks from a text file and
convert them into words; e.g.; 1992  “nineteen hundred and ninety two”.
"""
import re

def convert_number_to_words(number):
    # Mapping of digits to their word representations
    digit_words = {
        '0': 'zero', '1': 'one', '2': 'two', '3': 'three', '4': 'four',
        '5': 'five', '6': 'six', '7': 'seven', '8': 'eight', '9': 'nine'
    }

    # Mapping of two-digit numbers to their word representations
    two_digit_words = {
        '10': 'ten', '11': 'eleven', '12': 'twelve', '13': 'thirteen', '14': 'fourteen',
        '15': 'fifteen', '16': 'sixteen', '17': 'seventeen', '18': 'eighteen', '19': 'nineteen',
        '20': 'twenty', '30': 'thirty', '40': 'forty', '50': 'fifty',
        '60': 'sixty', '70': 'seventy', '80': 'eighty', '90': 'ninety'
    }

    if number == '0':
        return digit_words[number]

    if len(number) == 2:
        if number in two_digit_words:
            return two_digit_words[number]
        else:
            tens_digit = number[0] + '0'
            ones_digit = number[1]
            return two_digit_words[tens_digit] + ' ' + digit_words[ones_digit]

    if len(number) == 3:
        hundreds_digit = number[0]
        remaining_digits = number[1:]
        return digit_words[hundreds_digit] + ' hundred ' + convert_number_to_words(remaining_digits)

    if len(number) == 4:
        thousands_digit = number[0]
        remaining_digits = number[1:]
        return digit_words[thousands_digit] + ' thousand ' + convert_number_to_words(remaining_digits)

    return number

def convert_numerical_chunks_to_words(filename):
    with open(filename, 'r') as file:
        content = file.read()

    # Regular expression pattern to find numerical chunks
    pattern = r'\b\d+\b'
    numerical_chunks = re.findall(pattern, content)

    for chunk in numerical_chunks:
        word_representation = convert_number_to_words(chunk)
        content = content.replace(chunk, word_representation)

    # Write the updated content back to the file
    with open(filename, 'w') as file:
        file.write(content)

# Example usage
filename = '/home/samit/Desktop/Python/A1/text.txt'
convert_numerical_chunks_to_words(filename)
