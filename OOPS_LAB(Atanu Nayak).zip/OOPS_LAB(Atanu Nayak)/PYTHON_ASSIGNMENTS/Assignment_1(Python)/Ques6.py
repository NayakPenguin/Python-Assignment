"""Write a simple program which loops over a list of user data (tuples containing a username,
email and age) and adds each user to a directory if the user is at least 16 years old. You do
not need to store the age. Write a simple exception hierarchy which defines a different
exception for each of these error conditions:
 the username is not unique
 the age is not a positive integer
 the user is under 16
 the email address is not valid (a simple check for a username, the @ symbol and a
domain name is sufficient)
Raise these exceptions in your program where appropriate. Whenever an exception occurs,
your program should move onto the next set of data in the list. Print a different error
message for each different kind of exception.
"""

import re

class UsernameNotUniqueException(Exception):
    pass

class InvalidAgeException(Exception):
    pass

class UserUnder16Exception(Exception):
    pass

class InvalidEmailException(Exception):
    pass

class User:
    def __init__(self, username, email, age):
        self.username = username
        self.email = email
        self.age = age

def add_user_to_directory(user):
    # Add the user to the directory
    print(f"Adding user '{user.username}' to the directory.")

def is_valid_email(email):
    # A simple email validation check
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return re.match(pattern, email)

def process_user_data(user_data):
    directory = []

    for data in user_data:
        username, email, age = data

        try:
            if not is_valid_email(email):
                raise InvalidEmailException(f"Invalid email address: {email}")

            if age < 16:
                raise UserUnder16Exception(f"User '{username}' is under 16 years old.")

            if age <= 0:
                raise InvalidAgeException(f"Invalid age for user '{username}': {age}")

            # Check if the username is unique
            if username in directory:
                raise UsernameNotUniqueException(f"Username '{username}' is not unique.")

            # If all checks pass, add the user to the directory
            add_user_to_directory(User(username, email, age))
            directory.append(username)

        except UsernameNotUniqueException as e:
            print(f"Error: {e}")

        except InvalidAgeException as e:
            print(f"Error: {e}")

        except UserUnder16Exception as e:
            print(f"Error: {e}")

        except InvalidEmailException as e:
            print(f"Error: {e}")

# Example user data
user_data = [
    ("Samitinjaya", "samitinjaya@example.com", 20),
    ("Samit", "samit@example.com", 15),
    ("Sanidhya", "sanidhya@example", 25),
    ("Samitinjaya", "duplicate@example.com", 30)
]

# Process the user data
process_user_data(user_data)
