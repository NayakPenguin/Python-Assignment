#Write a discount coupon code using dictionary in Python with different rate coupons for
#each day of the week.

coupons = {
  "Monday": "MONDAY5",
  "Tuesday": "TUESDAY10",
  "Wednesday": "WEDNESDAY30",
  "Thursday": "THURSDAY15",
  "Friday": "FRIDAY50",
  "Saturday": "SATURDAY45",
  "Sunday": "SUNDAY50"
}

def todays_coupon(day_of_week):
  #Returns the discount coupon code for the given day of the week.
  return coupons[day_of_week]


day_of_week = input("Enter the day of the week : ")
coupon_code = todays_coupon(day_of_week)
print("The coupon code for today is: {}.".format(coupon_code))
