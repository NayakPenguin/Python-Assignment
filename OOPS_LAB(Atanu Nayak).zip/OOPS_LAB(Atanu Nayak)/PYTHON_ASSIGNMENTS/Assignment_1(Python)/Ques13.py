"""Write an operator overloading for len which shows string length for any given string
and return only length of repetitive words with the text if the text has some repetitive parts.
Determine the most frequently occurring words using most_common.
"""

import collections

class String:
    def __init__(self, text):
        self.text = text

    def __len__(self):
        words = self.text.split()
        counts = collections.Counter(words)
        return sum(counts[word] for word in words if counts[word] > 1)



text = "This is a test string with some repetitive words in a test"

string = String(text)
print(len(string))

    # Determine the most frequently occurring words
counts = collections.Counter(text.split())
most_common = counts.most_common(10)
print(most_common)
