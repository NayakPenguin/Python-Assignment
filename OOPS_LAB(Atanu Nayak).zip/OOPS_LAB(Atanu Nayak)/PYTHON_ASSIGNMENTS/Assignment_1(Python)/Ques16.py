""" Create a dictionary that maps stock names to prices, which will keep insertion
order.Find minimum price, maximum price and sort items according to their prices in first
dictionary. Create another second stock dictionary. Find items that are only in first dictionary
and find items whose prices do not match. Remove duplicate items from first dictionary.
Sort both dictionaries for incrementing prices. Group items in first dictionary by price in
multiple of 500. Find an item with price=800 from both dictionaries.
"""

from collections import OrderedDict

# Create the first stock dictionary
stock_prices = OrderedDict()
stock_prices['AAPL'] = 150.25
stock_prices['GOOGL'] = 2700.50
stock_prices['AMZN'] = 3500.75
stock_prices['TSLA'] = 650.80
stock_prices['MSFT'] = 300.60

# Find the minimum and maximum prices
min_price = min(stock_prices.values())
max_price = max(stock_prices.values())
print("Minimum Price:", min_price)
print("Maximum Price:", max_price)

# Sort the items by prices in the first dictionary
sorted_items = sorted(stock_prices.items(), key=lambda x: x[1])
print("Items Sorted by Prices:")
for item in sorted_items:
    print(item)

# Create the second stock dictionary
second_stock_prices = {'AAPL': 150.25, 'GOOGL': 2700.50, 'AMZN': 4000.0, 'FB': 350.40, 'MSFT': 300.60}

# Find items that are only in the first dictionary
items_only_in_first = set(stock_prices.keys()) - set(second_stock_prices.keys())
print("Items Only in First Dictionary:", items_only_in_first)

# Find items whose prices do not match
price_mismatch_items = {key: (stock_prices[key], second_stock_prices[key]) for key in stock_prices if key in second_stock_prices and stock_prices[key] != second_stock_prices[key]}
print("Items with Price Mismatch:", price_mismatch_items)

# Remove duplicate items from the first dictionary
stock_prices = OrderedDict.fromkeys(stock_prices)

# Sort both dictionaries by incrementing prices
stock_prices = OrderedDict(sorted(stock_prices.items(), key=lambda x: x[1]))
second_stock_prices = OrderedDict(sorted(second_stock_prices.items(), key=lambda x: x[1]))

# Group items in the first dictionary by price in multiples of 500
grouped_items = {}
for price in range(0, int(max(stock_prices.values())) + 500, 500):
    grouped_items[price] = [key for key, value in stock_prices.items() if value >= price and value < price + 500]

print("Items Grouped by Price:")
for price, items in grouped_items.items():
    print(f"Price Range: {price}-{price+500}")
    print("Items:", items)

# Find an item with price = 800 from both dictionaries
item_with_price_800 = next((key for key, value in stock_prices.items() if value == 800), None)
second_item_with_price_800 = next((key for key, value in second_stock_prices.items() if value == 800), None)
print("Item with Price 800 (First Dictionary):", item_with_price_800)
print("Item with Price 800 (Second Dictionary):", second_item_with_price_800)
