# Make a list of the largest or smallest N items in a collection

from heapq import nlargest, nsmallest

def get_largest_n(collection, n):
  """Returns a list of the largest N items in a collection.

  Args:
    collection: A collection of items.
    n: The number of items to return.

  Returns:
    A list of the largest N items in the collection.
  """

  largest_n = nlargest(n, collection)
  return largest_n


def get_smallest_n(collection, n):
  """Returns a list of the smallest N items in a collection.

  Args:
    collection: A collection of items.
    n: The number of items to return.

  Returns:
    A list of the smallest N items in the collection.
  """

  smallest_n = nsmallest(n, collection)
  return smallest_n

collection = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

largest_n = get_largest_n(collection, 3)
print(largest_n)  # [9, 10, 8]

smallest_n = get_smallest_n(collection, 3)
print(smallest_n)  # [1, 2, 3]
