# Print first 10 odd and even numbers using iterators and compress. 
# You can use duck typing

from itertools import count, compress

number = int(input("Enter the range "))
def numbers():
	for i in range(1,number,1):
		yield i

def odd():
	for i in range(1,number,1):
		if i%2==0:
			yield 0
		else:
			yield 1

def even():
	for i in range(1,number,1):
		if i%2==0:
			yield 1
		else:
			yield 0

odd_numbers =  list(compress(numbers(),odd()))
even_numbers = list(compress(numbers(),even()))

print(odd_numbers)
print(even_numbers)