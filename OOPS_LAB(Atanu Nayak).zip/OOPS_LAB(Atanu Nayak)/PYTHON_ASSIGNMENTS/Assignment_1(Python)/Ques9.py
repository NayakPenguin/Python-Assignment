# Enumerate the sequence of all lowercase ASCII letters, starting from 1, using
# enumerate.

from string import ascii_lowercase

for index, letter in enumerate(ascii_lowercase):
    print(index + 1, letter)
