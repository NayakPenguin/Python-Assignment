# Write a regular expression to validate a phone number

import re

print("Enter a number(in format 91-xxx-xxx-xxxx")
number = input();
pattern =r'^91-\d{3}-\d{3}-\d{4}$'
x = re.match(pattern, number)
if x :
	print("Valid Number")
else :
   print("Invalid Number")
