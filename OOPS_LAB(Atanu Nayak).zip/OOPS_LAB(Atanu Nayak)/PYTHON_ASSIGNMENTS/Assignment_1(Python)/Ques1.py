#Write a prime generator program using only primes and using python loops.


def is_prime(n):
  #Returns True if n is a prime number, otherwise returns false.
  if n <= 1:
    return False
  for i in range(2, n):
    if n % i == 0:
      return False
  return True

def prime_generator(n):
  #this function generates a list of prime numbers upto n
  #an array prime is used to store prime numbers
  #IF is_prime returns true then that number is appended in the array
  primes = []
  for i in range(2, n + 1):
    if is_prime(i):
      primes.append(i)
  return primes


n = int(input("Enter a number: "))
primes = prime_generator(n)
print("The prime numbers up to {} are: {}".format(n, primes))
