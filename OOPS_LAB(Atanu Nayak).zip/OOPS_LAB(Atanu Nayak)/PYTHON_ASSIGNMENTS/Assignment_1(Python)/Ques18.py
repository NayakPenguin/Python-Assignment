""" Use parameterized or nose_parameterized to compute power of following values:
(2, 2, 4),
(2, 3, 8),
(1, 9, 1),
(0, 9, 0). Use pytest to check errors"""

import pytest
from parameterized import parameterized


def power(x, y):
  """Computes the power of x to the yth power."""
  return x ** y


@parameterized([
    (2, 2, 4),
    (2, 3, 8),
    (1, 9, 1),
    (0, 9, 0),
])
def test_power(x, y, expected):
  """Tests that the power function returns the correct value."""
  actual = power(x, y)
  assert actual == expected, f"Expected {expected}, got {actual}"


if __name__ == "__main__":
  pytest.main()
