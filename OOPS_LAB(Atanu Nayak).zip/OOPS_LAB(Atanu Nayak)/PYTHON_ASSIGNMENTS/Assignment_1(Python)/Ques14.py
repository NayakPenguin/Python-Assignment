"""Implement a priority queue that sorts items by a given priority and always returns the
item with the highest priority on each pop operation.
"""

import heapq

class PriorityQueue:

    def __init__(self):
        self.queue = []

    def push(self, item, priority):
        heapq.heappush(self.queue, (priority, item))

    def pop(self):
        return heapq.heappop(self.queue)[1]

queue = PriorityQueue()

queue.push("A", 1)
queue.push("B", 2)
queue.push("C", 3)

print(queue.pop())  # A
print(queue.pop())  # B
print(queue.pop())  # C
