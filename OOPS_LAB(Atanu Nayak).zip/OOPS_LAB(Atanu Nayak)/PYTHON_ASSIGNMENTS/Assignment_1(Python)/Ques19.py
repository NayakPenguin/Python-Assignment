""" Use profile/cprofile to check pythogorian triples code in python. Think about time
complexity of the code.
"""
