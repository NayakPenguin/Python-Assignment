#Create a list of all the numbers up to N=50 which are multiples of five using anonymous
#function.


def is_multiple_of_five(x):
    return x % 5 == 0


numbers = list(range(1, 51))

multiples_of_five = list(filter(is_multiple_of_five, numbers))

print(multiples_of_five)
