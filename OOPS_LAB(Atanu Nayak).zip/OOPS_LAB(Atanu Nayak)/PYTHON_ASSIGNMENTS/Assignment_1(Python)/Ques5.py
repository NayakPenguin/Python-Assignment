# Write first seven Fibinacci numbers using generator next function/ yield in python. Trace
# and memorize the function. Also check whether a user given number is Fibinacci or not.

def fibonacci():
    a = 0
    b = 1
    while True:
        yield a 
        temp  = b
        a,b =b,a+b

fib = fibonacci()
for i in range(7):
    print(next(fib))

number = int(input("Enter a number : "))
fib2= fibonacci()

while True:
    generated_number = next(fib2)
    if number == generated_number:
        print("Entered number is a fibonacci number")
        break
    elif number <=generated_number:
        print("Entered number is not a fibonacci number")
        break