import java.util.Scanner;
import java.io.*;

class Ques4{
	public static void main(String[] args) {
		String []arr={"Samit","Sanidhya","Gourav","Pranab"};
		
		try{
			FileWriter fw = new FileWriter("/home/samit/Desktop/JAVA/LAB/A3/test1.txt");
			for(String str: arr){
				fw.write(str);
			}
			fw.close();
		}catch(Exception e){
			System.out.println("error opening file");
		}

		try{
			FileReader fr = new FileReader("/home/samit/Desktop/JAVA/LAB/A3/test1.txt");
			int i = 0;
			while((i=fr.read())!=-1){
				System.out.print((char)i);
			}
		}catch(Exception e){
			System.out.println("error opening file");
		}
	}
}