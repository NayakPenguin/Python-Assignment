

import java.util.Scanner;
import java.io.*;

class Ques3{
	public static void main(String[] args) {
		String filename;
		System.out.println("Enter the filename");
		Scanner scan = new Scanner(System.in);
		filename = scan.nextLine();

		File f =new File(filename);

		if(f.exists()){
			System.out.println("FILE "+filename+" EXISTS");
			if(f.isFile()){
				System.out.println("Entered filename is a FILE");
				if(f.canRead()){
					System.out.println("Yes the file can be read from.");
				}else{
					System.out.println("The file cannot be read from.");
				}
				if(f.canWrite()){
					System.out.println("The file can be written to.");
				}
				else{
					System.out.println("File cannot be written to");
				}
			}
			else if(f.isDirectory()){
				System.out.println("Entered filename is a DIRECTORY");
				System.out.println("List of files inside this directory:");

				File[] files =f.listFiles();
				if(files!= null){
					for(File f2 : files){
						System.out.println(f2.getName());
					}
				}
			}
		}
		else{
			System.out.println("FILE DOES NOT EXIST.");
		}
	}
}