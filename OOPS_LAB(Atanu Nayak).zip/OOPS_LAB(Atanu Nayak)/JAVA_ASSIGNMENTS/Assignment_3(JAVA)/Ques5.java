import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

class Student implements Serializable{
    private int roll;
    private String name;
    private double score;

    public Student(int roll,String name,float score){
        this.roll = roll;
        this.name = name;
        this.score = score;
    }

    public String getName(){
        return name;
    }

    public int getRoll(){
        return roll;
    }

    public double getScore(){
        return score;
    }
}



public class Ques5 {

    public void readFile() throws IOException{
        ObjectOutputStream fout = new ObjectOutputStream(new FileOutputStream("objNames.txt"));

        ArrayList<Student> students = new ArrayList<>();
        students.add(new Student(1, "Protyay Ray", 90));
        students.add(new Student(2, "Rajiv Ray", 96));
        students.add(new Student(3, "Bijoy Ray", 94));
        
        fout.writeObject(students);
        fout.close();
    }

    public void writeFile(){
       
        try {
             ObjectInputStream fin = new ObjectInputStream(new FileInputStream("objNames.txt"));

            ArrayList<Student> studentsFromFile = (ArrayList<Student>) fin.readObject();

            System.out.println("Student objects read from the file:");
            for (Student student : studentsFromFile) {
                System.out.println("Name: " + student.getName() + ", roll: " + student.getRoll()+", score: "+student.getScore());
            }
            
            fin.close();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("An error occurred while reading student objects from the file.");
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws IOException{
       Ques5 obj = new Ques5();
       obj.readFile();
    //    obj.writeFile();
    }
}
