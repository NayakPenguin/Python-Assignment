//Design a BankAcct class with account number, balance and interest rate as attributes.
//interest rate is same for all account. Support must be there to initialize, change
//And display the insterest rate. Also supports are to be there to return balance
//and calculate interest.



/*Here in this bank account classvthe attributes are defines as stated and
static iR is used to hold the interest rate which is same for all accounts
There is a constructor to initialize account number and balance
There is a method to setInterest rate and other setter and getter
There is a method to dispay the interest rate and another method to calculate
the balance after calculating the interest*/
class BankAcct{
	int accountNumber;
    double balance;
    static double iR;

    BankAcct(int ac, double b){
        accountNumber = ac;
        balance = b;
    }

    static void setInterest(double i){
        iR = i; 
    }

    static double getInterest(){
        return iR;
    }
    
    static void displayInterest(){
        System.out.println("Interest Rate is : "+iR);
    }
    void calInterest(){
        double interest = (balance*iR)/100;
        balance += interest;
    }

    double getBalance(){
        return balance;
    }
    int getAccount(){
        return accountNumber;
    }
    
}

class Ques9{
	public static void main(String args[]){
        BankAcct A1 = new BankAcct(10,1000);
        A1.setInterest(10.0);
        A1.calInterest();
        System.out.println("Account No. : "+A1.getAccount());
        System.out.println("Interest rate : "+A1.getInterest());
        System.out.println("The balance after calclating interest rate is : "+ A1.getBalance());
		
	}
}