//Write a program that accepts a <string and assigns it to another. 
//Check the outcome of comparison with == and equals () method. 
//Take two strings and put same input for the. repeat the equality checking.
// Observe the outcome.

import java.util.Scanner;

class Ques5{
	public static void main(String args[]){
		String str1,str2;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the string: ");
		str1 = sc.nextLine();
		str2 = str1;

		/*boolean is used to store the result of == and .equals() method
		== checks if the reference points to the same object
		and .equals() compare the contents of each oject with the other object
		*/
		boolean comp1 = str1==str2;
		boolean comp2 = str1.equals(str2);
		System.out.println(comp1);
		System.out.println(comp2);
		
		String str3,str4;
		str3 = sc.nextLine();
		str4 = sc.nextLine();
		boolean comp3 = str3==str4;
		boolean comp4 = str3.equals(str4);
		System.out.println(comp3);
		System.out.println(comp4);
		
	}
}
