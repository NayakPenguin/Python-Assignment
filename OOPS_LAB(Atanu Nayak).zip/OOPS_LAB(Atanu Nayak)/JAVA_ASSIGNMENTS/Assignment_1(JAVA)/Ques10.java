//for a programme(such as, BCSE),each instructor has name and phone number.
//Each text book has a title, author name and publisher. each course (that is, subject)
//has a course name, instructor and text book.
//One can set the data for a textbook and view the same
//One can view instructor information and set the information
//One can set the course data and view the same
//Design and implement the classes



/* Here a class Instructor is made with the necessary constructor and methods to set 
get the attributes name and phone number. A method to display the Instructor is also
present.*/
class Instructor{
    String name;
    int phoneNumber;

    Instructor(String name, int ph){
        this.name = name;
        phoneNumber=ph;
    }
    String getName(){
        return name; 
    }
    int getPhone(){
        return phoneNumber;
    }
    void display(){
        System.out.println("Instructor name : "+name);
        System.out.println("Phone Number : "+phoneNumber);
    }
}

/*Similarly a class TExtbook is defined */
class Textbook{
    String title;
    String author;
    String publisher;
    
    Textbook(String title, String author, String publisher){
        this.title = title;
        this.author = author;
        this.publisher = publisher;
    }
    String getTitle(){
        return title;
    }

    String getAuthor(){
        return author;
    }

    String getPublisher(){
        return publisher;
    }

    void display(){
        System.out.println("Title is : "+title);
        System.out.println("Author is : "+author);
        System.out.println("Publisher is : "+publisher);
    }
}

/* And similarly a class Course is defined*/
class Course{
    Instructor sir;
    Textbook book;
    String name;

    Course(String name){
        this.name = name;
    }
    void setData(Instructor i, Textbook t){
        sir=i;
        book = t;
    }
    void display(){
        System.out.println("Course name is : "+name);
        System.out.println("Instructor Details : ");
        sir.display();
        System.out.println("Textbook Details : ");
        book.display();
    }
    void setName(String name){
        this.name = name; 
    }
    void setInstructor(Instructor i){
        sir = i;
    }
    void setTextbook(Textbook t){
        book = t;
    }

    String getName(){
        return name;
    }
}

class Ques10{
    public static void main(String args[]){
        /*Here object of each class is created one by one andvthen displayed*/
        Instructor i = new Instructor("Amit", 9797);
        Textbook t = new Textbook("JAVA", "Suresh", "TATA");
        Course cse = new Course("BCSE");
        cse.setData(i,t);
        cse.display(); 
    }
}