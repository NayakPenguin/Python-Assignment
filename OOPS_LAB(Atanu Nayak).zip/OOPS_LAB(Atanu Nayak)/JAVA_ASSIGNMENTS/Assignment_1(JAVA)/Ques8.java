//Add constructors in the Student8 class of earlier problem so that objects can be 
//created with1)roll only, 2)roll and name only 3)roll, name and score. 4)no value
//Also include a copy constructor. Check whether constructors are working or not. 
//Verify, copy constructor results into deep copy or not



/* here the Student8 class is similar to the class in question7 but here we have used
constructors in this Student8 class. There is also a copy constructor which is used to
copy the details of one student object to another.
And yes the copy constructor results in a deep copy*/

class Student8{
	int roll,score;
	String name;

	Student8(){

	}

	Student8(int roll){
		this.roll = roll;
	}
	Student8(int roll, String name){
		this.roll = roll;
		this.name = name;
	}
	Student8(int roll, String name, int score){
		this.roll = roll;
		this.score = score;
		this.name = name;
	}

	Student8(Student8 S){
		this.roll = S.getRoll();
		this.score = S.getScore();
		this.name = S.getName();
	}

	void setRoll(int roll){
		this.roll= roll;
	}
	void setScore(int score){
		this.score = score;
	}
	void setName(String name){
		this.name = name;
	}
	int getRoll(){
		return roll;
	}
	int getScore(){
		return score;
	}
	String getName(){
		return name;
	}

	void display(){
		System.out.println("Roll is : "+roll);
		System.out.println("Score is : "+score);
		System.out.println("Name is : "+name);
	}

	void copyTo(Student8 S){
		S.setRoll(this.roll);
		S.setScore(this.score);
		S.setName(this.name);
	}
}

class Ques8{
	public static void main(String args[]){
		Student8 S1 = new Student8();
		S1.setRoll(2);
		S1.setScore(78);
		S1.setName("Arjun");
		S1.display();

		Student8 S2 = new Student8(S1);
		S2.display();
		S1.setName("Rahul");
		boolean check = S1 != S2;

		/*Name of student S1 and S2 are different thus indicating that it is 
		indeed a deep copy*/
		
		S1.display();
		S2.display();
		System.out.println("DeepCopy = "+check);
	}
}