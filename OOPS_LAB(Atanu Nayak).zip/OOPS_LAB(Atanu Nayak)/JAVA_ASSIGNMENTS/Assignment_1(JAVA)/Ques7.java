/*Question. Design and implement Student7 class with roll, name and score as attributes.
 It will have methods to set attributes(attribute values passed as arguments). 
 Display the attributes, copy( that copies the content of invoking object to
  another object passed as arguments). Verify that methods are working properly.*/

/*class Student7 with attibutes roll,name and score
setters and getters are used to modify and return the attributes and
display fucntion is used to display the details of a student
copyTo function is used to copy the details from anoter student object to a student object
*/
class Student7{
	int roll,score;
	String name;
	void setRoll(int roll){
		this.roll= roll;
	}
	void setScore(int score){
		this.score = score;
	}
	void setName(String name){
		this.name = name;
	}
	int getRoll(){
		return roll;
	}
	int getScore(){
		return score;
	}
	String getName(){
		return name;
	}

	void display(){
		System.out.println("Roll is : "+roll);
		System.out.println("Score is : "+score);
		System.out.println("Name is : "+name);
	}

	void copyTo(Student7 S){
		S.setRoll(this.roll);
		S.setScore(this.score);
		S.setName(this.name);
	}
}

class Ques7{
	public static void main(String args[]){
		Student7 S1 = new Student7();
		S1.setRoll(2);
		S1.setScore(78);
		S1.setName("Arjun");
		S1.display();

		Student7 S2 = new Student7();
		S1.copyTo(S2);
		S2.display();
	}
}
