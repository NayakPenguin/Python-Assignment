//Write a program that accepts radius of a circle and displays area of the circle. Declare a constant pi equals to 3.14 using the OOP concept

import java.util.Scanner;

/*class circle is made with pi = 3.14f being final so that it cannot be 
changed for any object and static so that it remain same for all objects
There is a function setradius which sets the radius and calculates area
according to that radius*/

class circle{
	final static float pi = 3.14f;
	float rad,area;
	void setradius(float a){
		rad = a;
		area = rad*rad*pi;
	}
	float getarea(){
		return area;
	}
}

class Ques3{
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);

		//new object of class circle is declared
		circle c = new circle();
		
		//gets radius from the user and print the area of the circle
		System.out.println("Enter the radius of the circle");
		float rad;
		rad = sc.nextFloat();
		c.setradius(rad);
		System.out.println("The area of the circle is "+c.getarea());
		
	}
}

