//Write a program that accepts number of command line parameters 
//and displays the parameters and count of such parameters.

class Ques2{
	public static void main(String args[]){
		int count, i=0;
		String string;

		//getting the number of arguments passed during runtime into count
		count = args.length;
		System.out.println("Number of arguments = "+count);

		//using a loop to print all the passed arguments one by one
		while(i<count)
		{
			string = args[i];
			i = i + 1;
			System.out.println("Subject is " + string);
		}
		
	}
}
