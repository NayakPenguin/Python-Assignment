//Write a program to accept two short integers from user and display the sum

import java.util.Scanner;

class Ques1{
	public static void main(String args[]){
		short a,b;
		//creating a new object of scanner class to get user input
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the two number:");
		//nextShort()is a method to get a short number from user
		a= sc.nextShort();
		b = sc.nextShort();
		System.out.print("The required sum is ");
		System.out.println(a+b);
	}

}
