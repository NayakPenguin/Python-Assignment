/*Write a program where class contains void show(int) to display the argument passed.
 Call the function once with short as actual parameter and again double as
  actual parameter. Add another function as void show(double). 
  Repeat the calls. Observe the outcomes in each case.*/

class test{
	void show(int a){
		System.out.println(a);
	}
	void show(double d){
		System.out.println(d);
	}
}

class Ques6{
	public static void main(String args[]){
		System.out.println("Hello");
		
		test t = new test();
		
		short s = 3;
		//this will call show(int a) method
		t.show(s);

		//this will call show(double d) method
		t.show(3.14);
	}
}
