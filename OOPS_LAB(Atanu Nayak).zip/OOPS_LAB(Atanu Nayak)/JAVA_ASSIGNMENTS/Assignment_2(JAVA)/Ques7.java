//Take a String input that contains multiple words. Do the following 1)number of times "a"
// appears 2)number of times "and" appears 3)whether it starts with "The" or not
// 4)put the String into an array of characters 5)display the tokens int the String
// (tokens are substrings separated by space or @ or.)

import java.util.Scanner;

class Ques7{
	public static void main(String[] args) {
		System.out.print("Enter a String : ");
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		
		
		int count1=0;
		for(int i=0; i<str.length(); i++){
			if(str.charAt(i)=='a'){
				count1++;
			}
		}
		System.out.println("No. of times 'a' appears is "+count1);
		int count2=0;
		int i =0;
		for(i=0 ; i<str.length()-2;i++){
			if(str.startsWith("and",i)){
				count2++;
			}
		}
		System.out.println("No. of times 'and' appears is "+count2);

		if(str.startsWith("The")){
			System.out.println("Yes it starts with The");
		}
		else{
			System.out.println("It doesn't start with The");
		}

		char []ctr = new char[str.length()	];
		ctr = str.toCharArray();

		
		for(i=0 ; i<str.length();i++){
			char x= str.charAt(i);
			if(x==' '||x=='@'||x=='.'){
				System.out.println();
			}
			else{
				System.out.print(x);
			}
		}
	}


}