/*Each customer of a bank has customer id, name, and current loan ammount and phone number. 
One can change the attributes like name, phone number. A customer may ask for loan of certain amount
It is grranted provided the sum of current loan ammount asked amount does not exceed credit limit
(fixed amount for all customers). A customer may be a priviledged account. For such customers 
credit limit is higher. Once a loan is sanctioned necessary updates should be made. Any type of
customer should be able to find his credit limit, current loan amount and amount of loan 
he can seek.Design and imolement the classes.*/

class Bank{
	final int creditLimit;
	String name;
	int customerId;
	int currentLoan;
	int phoneNo;

	Bank(String name, int id, int ph, boolean priviledged){

		this.name = name;
		customerId = id;
		phoneNo = ph;
		currentLoan = 0;

		if(priviledged==true){
			creditLimit=1000000;
		}
		else{
			creditLimit=100000;
		}
	}

	void changeAttributes(String name, int ph){
		this.name = name;
		phoneNo = ph;
	}

	void viewCreditLimit(){
		System.out.println("Your credit Limit is "+creditLimit);
	}

	void loanAllowed(){
		System.out.print("You can take a loan upto :");
		System.out.println(creditLimit-currentLoan);
	}

	void takeLoan(int value){
		if(value>(creditLimit-currentLoan)){
			System.out.println("You cannot take a loan of this amount");
		}
		else{
			System.out.println("Loan granted of amount : "+value);
			currentLoan+=value;
		}
	}
}

class Ques1{
	public static void main(String args[]){

		System.out.println("Account 1");
		Bank account1=new Bank("Samit", 4, 9797, true);
		account1.viewCreditLimit();
		account1.changeAttributes("SAMIT",7051);
		account1.loanAllowed();		
		account1.takeLoan(500000);

		System.out.println("Account 2");
		Bank account2=new Bank("Amit", 6, 9419, false);
		account2.viewCreditLimit();
		account2.changeAttributes("SAMIT",9797);
		account2.loanAllowed();		
		account2.takeLoan(500000);
	}
} 