/* For every person in an institute details like name, address(consists of premises number,
street, city, pin and state), phone number , e-mail id are maintained. A person is either a
student or a faculty. For student roll number and course of study are to be maintained. For 
faculty employee id, department and specialization are to be stored. One should be able to 
view the object details and set the attributes. For address, one may change it partially 
depending on the choice. Design and implement the classes.*/

class Address{
	int premisesNumber;
	String street;
	String city;
	int pin;
	String state;
	Address(int pm, String street, String city, int pin, String state){
		premisesNumber=pm;
		this.street = street;
		this.city = city;
		this.pin = pin;
		this.state = state;
	}
	void display(){
		System.out.println("Premesis No."+premisesNumber);
		System.out.println("street: "+street);
		System.out.println("City: "+city);
		System.out.println("Pin: "+pin);
		System.out.println("State: "+state);
	}
	void changePremesis(int pm){
		premisesNumber=pm;
	}
	void changeStreet(String street){
		this.street = street;
	}
	void changeCity(String city){
		this.city = city;
	}
	void changePin(int pin){
		this.pin = pin;
	}
	void changeState(String state){
		this.state = state;
	}




}

class Person {
	String name;
	int ph;
	String email;
	Address ad ;
	Person(int pm, String street, String city, int pin, String state, String name, int ph, String email){
		ad = new Address(pm,street,city,pin,state);
		this.name = name;
		this.ph = ph;
		this.email = email;
	}
	void display(){
		System.out.println("NAME is : "+name);
		System.out.println("PHONE NUMBER is : "+ph);
		System.out.println("EMAIL is : "+email);
		ad.display();
	}

}

class Student extends Person{
	int rollNo;
	String course;
	Student(int pm, String street, String city, int pin, String state, String name, int ph, String email, int roll, String Course){
		super(pm,street,city,pin,state,name,ph,email);
		rollNo = roll;
		this.course = course;
	}
	void studentDisplay(){
		System.out.println("********Display*********");
		System.out.println("Roll no is : "+rollNo);
		System.out.println("Course is : "+course);
	}
}

class Faculty extends Person{
	int eId;
	String department;
	String specialization;
	Faculty(int pm, String street, String city, int pin, String state, String name, int ph, String email, int eId, String department, String specialization){
		super(pm,street,city,pin,state,name,ph,email);
		this.eId = eId;
		this.department = department;
		this.specialization = specialization;
	}
	void FacultyDisplay(){
		System.out.println("*******DISPLAY*******");
		System.out.println("Employee id no is : "+eId);
		System.out.println("Department is : "+department);
		System.out.println("Specialization is:"+specialization);
	}
}

class Ques2{
	public static void main(String[] args) {
		System.out.println("Hello");
		Student S1;
		S1 = new Student(29,"Middle Road","Kolkata",700075,"WB","Samit",9797,"S@mail.com",1088,"CSE");
		S1.studentDisplay();
		S1.display();

	
		Faculty T1;
		T1 = new Faculty(29,"Middle Road","Kolkata",700075,"WB","Teacher",7051,"T@mail.com",199,"CSE","JAVA");
		T1.FacultyDisplay();
		T1.display();
	}
}