class Ques6{
	public static void main(String[] args) {
		//basic type to object type
		Integer O1= Integer.valueOf(100);
		System.out.println(O1);

		// Object type to basic type
		int i = O1.intValue();
		System.out.println(i);

		// basic type to String
		String str = String.valueOf(i);
		System.out.println(str);

		//String type to numeric object
		try{
			Integer O2 = Integer.valueOf("134");
			System.out.println(O2);
		}catch(NumberFormatException e){
			System.out.println("Invalid Format");
		}
		//object to string type
		String str2 = String.valueOf(O1);
		System.out.println(str2);


	}
}