// Design a student class with roll, name and score. Support must be there to set the score.
// Score is non-negative and cannot exceed 100. For invalid score an exception has to be raised
// User of set score method will decide about the measures to deal with the exception.

class Student5{
	int roll;
	String name;
	double score;
	void setRoll(int roll){
		this.roll = roll;
	}
	void setName(String name){
		this.name = name;
	}
	void setScore(double score){
		this.score = score;
	}
	void display(){
		System.out.println("Roll :- "+roll);
		System.out.println("Name :- "+name);
		System.out.println("Score:- "+score);
	}
}

class Ques5{
	public static void main(String[] args) {
		Student5 S1= new Student5();
		S1.setRoll(2);
		S1.setName("Amit");
		S1.setScore(79.9);
		S1.display();
		
	}
}